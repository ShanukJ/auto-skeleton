export { AutoSkeleton } from './AutoSkeleton';
export type { SkeletonConfig, SkeletonNode } from './types';
